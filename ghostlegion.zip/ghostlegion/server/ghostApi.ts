import { COOKIE_NAME } from "@shared/const";
import type { AuthenticatedUser } from "./_core/sdk";
import { sdk } from "./_core/sdk";
import { getSessionCookieOptions } from "./_core/cookies";
import type { Express, NextFunction, Request, Response } from "express";
import * as keyStore from "./keyStore";

interface AdminRequest extends Request {
  adminUser?: AuthenticatedUser;
}

function publicApiCors(_req: Request, res: Response, next: NextFunction) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Cache-Control", "no-store");
  next();
}

async function adminOnly(req: AdminRequest, res: Response, next: NextFunction) {
  try {
    const user = await sdk.authenticateRequest(req);
    if (user.role !== "admin") {
      res.status(403).json({ error: "admin_required", message: "Administrator access is required." });
      return;
    }
    req.adminUser = user;
    next();
  } catch {
    res.status(401).json({ error: "login_required", message: "Sign in to the administrator account." });
  }
}

function getValidationInput(body: unknown): { key: string; deviceId?: string } | null {
  if (!body || typeof body !== "object") return null;
  const value = body as Record<string, unknown>;
  const rawKey = value.key ?? value.license_key ?? value.licenseKey;
  const rawDevice = value.device_id ?? value.deviceId ?? value.hwid;
  if (typeof rawKey !== "string" || !rawKey.trim()) return null;
  if (rawDevice !== undefined && typeof rawDevice !== "string") return null;
  return { key: rawKey, deviceId: typeof rawDevice === "string" ? rawDevice : undefined };
}

async function handleValidation(req: Request, res: Response) {
  const input = getValidationInput(req.body);
  if (!input) {
    res.status(400).json({ valid: false, status: "invalid", code: "missing_key", message: "Provide a key and an optional device_id." });
    return;
  }
  try {
    const result = await keyStore.validateKey(input.key, input.deviceId);
    const statusCode = result.valid ? 200 : result.code === "invalid_format" ? 400 : result.code === "key_not_found" ? 404 : 403;
    res.status(statusCode).json(result);
  } catch (error) {
    console.error("[Ghost API] Key validation failed:", error instanceof Error ? error.message : "unknown error");
    res.status(503).json({ valid: false, status: "error", code: "service_unavailable", message: "Key validation is temporarily unavailable." });
  }
}

export function registerGhostApi(app: Express) {
  app.options("/api", publicApiCors, (_req, res) => res.status(204).end());
  app.options("/api/validate", publicApiCors, (_req, res) => res.status(204).end());

  app.get("/api", publicApiCors, (_req, res) => {
    res.json({
      service: "Ghost Legion Key Validator",
      status: "online",
      version: "1.0.0",
      keyFormat: "XXXXX-XXXXX-XXXXX-XXXXX",
      alphabet: "uppercase hexadecimal",
      endpoints: [
        { method: "GET", path: "/api", description: "Service status and integration details." },
        { method: "POST", path: "/api", description: "Validate a license key." },
        { method: "POST", path: "/api/validate", description: "Validate a license key." },
      ],
      request: { key: "F228F-DE337-ED406-E2912", device_id: "YOUR_DEVICE_ID" },
      response: { valid: true, status: "active", message: "License key is valid.", expiresAt: null, uses: 1, deviceId: "YOUR_DEVICE_ID" },
    });
  });
  app.post("/api", publicApiCors, handleValidation);
  app.get("/api/validate", publicApiCors, (_req, res) => {
    res.json({
      endpoint: "POST /api/validate",
      description: "Validates a Ghost Legion license key and optionally binds the first device identifier supplied.",
      keyFormat: "XXXXX-XXXXX-XXXXX-XXXXX",
      request: { key: "F228F-DE337-ED406-E2912", device_id: "YOUR_DEVICE_ID" },
    });
  });
  app.post("/api/validate", publicApiCors, handleValidation);

  app.get("/api/admin/session", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      res.setHeader("Cache-Control", "no-store");
      res.json({ authenticated: true, isAdmin: user.role === "admin", user: { name: user.name, email: user.email } });
    } catch {
      res.setHeader("Cache-Control", "no-store");
      res.json({ authenticated: false, isAdmin: false });
    }
  });

  app.post("/api/admin/logout", (_req, res) => {
    res.clearCookie(COOKIE_NAME, { ...getSessionCookieOptions(_req), maxAge: -1 });
    res.json({ success: true });
  });

  app.get("/api/admin/keys", adminOnly, async (_req: AdminRequest, res) => {
    try {
      res.setHeader("Cache-Control", "no-store");
      res.json({ keys: await keyStore.listKeys() });
    } catch (error) {
      console.error("[Ghost API] Could not list keys:", error instanceof Error ? error.message : "unknown error");
      res.status(503).json({ error: "service_unavailable", message: "The key store is temporarily unavailable." });
    }
  });

  app.post("/api/admin/keys", adminOnly, async (req: AdminRequest, res) => {
    const body = req.body && typeof req.body === "object" ? req.body as Record<string, unknown> : {};
    const quantity = Number(body.quantity ?? 1);
    const duration = body.duration;
    const allowedDurations = new Set(["1d", "7d", "30d", "90d", "365d", "lifetime", "custom"]);
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 100 || typeof duration !== "string" || !allowedDurations.has(duration)) {
      res.status(400).json({ error: "invalid_request", message: "Choose 1–100 keys and a supported duration." });
      return;
    }
    try {
      const keys = await keyStore.createKeys({
        quantity,
        duration: duration as keyStore.KeyDuration,
        customDays: body.customDays === undefined ? undefined : Number(body.customDays),
        note: typeof body.note === "string" ? body.note : undefined,
      });
      res.status(201).json({ keys });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Could not generate keys.";
      res.status(400).json({ error: "generation_failed", message });
    }
  });

  app.post("/api/admin/keys/:key/action", adminOnly, async (req: AdminRequest, res) => {
    const action = req.body?.action;
    if (action !== "revoke" && action !== "restore" && action !== "unlock") {
      res.status(400).json({ error: "invalid_action", message: "Use revoke, restore, or unlock." });
      return;
    }
    try {
      const updated = await keyStore.changeKey(req.params.key.toUpperCase(), action);
      if (!updated) {
        res.status(404).json({ error: "not_found", message: "License key was not found." });
        return;
      }
      res.json({ success: true });
    } catch (error) {
      console.error("[Ghost API] Could not update key:", error instanceof Error ? error.message : "unknown error");
      res.status(503).json({ error: "service_unavailable", message: "The key store is temporarily unavailable." });
    }
  });

  app.delete("/api/admin/keys/:key", adminOnly, async (req: AdminRequest, res) => {
    try {
      const deleted = await keyStore.deleteKey(req.params.key.toUpperCase());
      if (!deleted) {
        res.status(404).json({ error: "not_found", message: "License key was not found." });
        return;
      }
      res.json({ success: true });
    } catch (error) {
      console.error("[Ghost API] Could not delete key:", error instanceof Error ? error.message : "unknown error");
      res.status(503).json({ error: "service_unavailable", message: "The key store is temporarily unavailable." });
    }
  });
}
