import { randomBytes } from "node:crypto";
import { createPool, type Pool, type RowDataPacket } from "mysql2/promise";

export type KeyStatus = "active" | "expired" | "revoked";
export type KeyDuration = "1d" | "7d" | "30d" | "90d" | "365d" | "lifetime" | "custom";

export type LicenseKey = {
  key: string;
  duration: string;
  note: string | null;
  createdAt: string;
  expiresAt: string | null;
  deviceId: string | null;
  deviceLocked: boolean;
  status: KeyStatus;
  uses: number;
};

type DbKey = RowDataPacket & {
  licenseKey: string;
  durationLabel: string;
  note: string | null;
  createdAt: string;
  expiresAt: string | null;
  deviceId: string | null;
  deviceLocked: number;
  status: "active" | "revoked";
  uses: number;
};

let pool: Pool | undefined;
let schemaPromise: Promise<void> | undefined;

function db(): Pool {
  if (pool) return pool;
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error("DATABASE_URL is not configured");
  pool = createPool(url);
  return pool;
}

function mysqlUtc(date: Date): string {
  return date.toISOString().slice(0, 19).replace("T", " ");
}

function toLicenseKey(row: DbKey): LicenseKey {
  const expired = Boolean(row.expiresAt && Date.parse(row.expiresAt) <= Date.now());
  return {
    key: row.licenseKey,
    duration: row.durationLabel,
    note: row.note,
    createdAt: row.createdAt,
    expiresAt: row.expiresAt,
    deviceId: row.deviceId,
    deviceLocked: Boolean(row.deviceLocked),
    status: row.status === "revoked" ? "revoked" : expired ? "expired" : "active",
    uses: Number(row.uses),
  };
}

const selectColumns = `
  license_key AS licenseKey,
  duration_label AS durationLabel,
  note,
  DATE_FORMAT(created_at, '%Y-%m-%dT%H:%i:%sZ') AS createdAt,
  DATE_FORMAT(expires_at, '%Y-%m-%dT%H:%i:%sZ') AS expiresAt,
  device_id AS deviceId,
  device_locked AS deviceLocked,
  status,
  uses
`;

export async function ensureKeySchema(): Promise<void> {
  if (!schemaPromise) {
    schemaPromise = db().query(`
      CREATE TABLE IF NOT EXISTS ghost_license_keys (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        license_key CHAR(23) NOT NULL UNIQUE,
        duration_label VARCHAR(32) NOT NULL,
        note VARCHAR(255) NULL,
        created_at DATETIME NOT NULL,
        expires_at DATETIME NULL,
        device_id VARCHAR(128) NULL,
        device_locked TINYINT(1) NOT NULL DEFAULT 0,
        status ENUM('active', 'revoked') NOT NULL DEFAULT 'active',
        uses INT UNSIGNED NOT NULL DEFAULT 0,
        last_used_at DATETIME NULL,
        INDEX idx_ghost_keys_created (created_at),
        INDEX idx_ghost_keys_status_expiry (status, expires_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `).then(async () => {
      await db().query(`
        CREATE TABLE IF NOT EXISTS ghost_admin_owner (
          singleton TINYINT NOT NULL PRIMARY KEY,
          open_id VARCHAR(64) NOT NULL,
          created_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
      `);
    }).then(() => undefined).catch(error => {
      schemaPromise = undefined;
      throw error;
    });
  }
  await schemaPromise;
}

export async function claimFirstAdmin(openId: string): Promise<boolean> {
  await ensureKeySchema();
  const configuredOwner = process.env.OWNER_OPEN_ID;
  if (configuredOwner) {
    if (configuredOwner !== openId) return false;
    await db().execute(`UPDATE users SET role = 'admin' WHERE \`openId\` = ?`, [openId]);
    return true;
  }
  await db().execute(
    `INSERT IGNORE INTO ghost_admin_owner (singleton, open_id, created_at) VALUES (1, ?, ?)`,
    [openId, mysqlUtc(new Date())],
  );
  const [rows] = await db().execute<(RowDataPacket & { openId: string })[]>(`SELECT open_id AS openId FROM ghost_admin_owner WHERE singleton = 1`);
  const isFirstAdmin = rows[0]?.openId === openId;
  if (isFirstAdmin) await db().execute(`UPDATE users SET role = 'admin' WHERE \`openId\` = ?`, [openId]);
  return isFirstAdmin;
}

function expiryFor(duration: KeyDuration, customDays?: number): { label: string; expiresAt: string | null } {
  const days: Partial<Record<KeyDuration, number>> = {
    "1d": 1,
    "7d": 7,
    "30d": 30,
    "90d": 90,
    "365d": 365,
  };
  if (duration === "lifetime") return { label: "Lifetime", expiresAt: "2597-12-10 19:01:00" };
  const length = duration === "custom" ? customDays : days[duration];
  if (!Number.isInteger(length) || !length || length < 1 || length > 365) {
    throw new Error("Duration must be between 1 and 365 days");
  }
  const label = duration === "custom" ? `${length} days` : `${length} ${length === 1 ? "day" : "days"}`;
  return { label, expiresAt: mysqlUtc(new Date(Date.now() + length * 86_400_000)) };
}

function makeKey(): string {
  const hex = randomBytes(10).toString("hex").toUpperCase();
  return hex.match(/.{5}/g)!.join("-");
}

export async function createKeys(input: {
  quantity: number;
  duration: KeyDuration;
  customDays?: number;
  note?: string;
}): Promise<LicenseKey[]> {
  await ensureKeySchema();
  const quantity = Math.max(1, Math.min(100, Math.floor(input.quantity)));
  const { label, expiresAt } = expiryFor(input.duration, input.customDays);
  const note = input.note?.trim().slice(0, 255) || null;
  const createdAt = mysqlUtc(new Date());
  const connection = await db().getConnection();
  const generated: LicenseKey[] = [];
  try {
    await connection.beginTransaction();
    for (let index = 0; index < quantity; index += 1) {
      let key = makeKey();
      let inserted = false;
      for (let attempt = 0; attempt < 3 && !inserted; attempt += 1) {
        try {
          await connection.execute(
            `INSERT INTO ghost_license_keys (license_key, duration_label, note, created_at, expires_at)
             VALUES (?, ?, ?, ?, ?)`,
            [key, label, note, createdAt, expiresAt],
          );
          inserted = true;
        } catch (error) {
          if ((error as { code?: string }).code !== "ER_DUP_ENTRY" || attempt === 2) throw error;
          key = makeKey();
        }
      }
      generated.push({ key, duration: label, note, createdAt: new Date(`${createdAt.replace(" ", "T")}Z`).toISOString(), expiresAt: expiresAt ? new Date(`${expiresAt.replace(" ", "T")}Z`).toISOString() : null, deviceId: null, deviceLocked: false, status: "active", uses: 0 });
    }
    await connection.commit();
    return generated;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export async function listKeys(): Promise<LicenseKey[]> {
  await ensureKeySchema();
  const [rows] = await db().query<DbKey[]>(`SELECT ${selectColumns} FROM ghost_license_keys ORDER BY created_at DESC LIMIT 1000`);
  return rows.map(toLicenseKey);
}

export async function changeKey(key: string, action: "revoke" | "restore" | "unlock"): Promise<boolean> {
  await ensureKeySchema();
  if (action === "unlock") {
    const [result] = await db().execute(`UPDATE ghost_license_keys SET device_id = NULL, device_locked = 0 WHERE license_key = ?`, [key]);
    return (result as { affectedRows: number }).affectedRows > 0;
  }
  const [result] = await db().execute(`UPDATE ghost_license_keys SET status = ? WHERE license_key = ?`, [action === "revoke" ? "revoked" : "active", key]);
  return (result as { affectedRows: number }).affectedRows > 0;
}

export async function deleteKey(key: string): Promise<boolean> {
  await ensureKeySchema();
  const [result] = await db().execute(`DELETE FROM ghost_license_keys WHERE license_key = ?`, [key]);
  return (result as { affectedRows: number }).affectedRows > 0;
}

export type ValidationResult =
  | { valid: true; status: "active"; message: string; key: string; expiresAt: string | null; uses: number; deviceId: string | null }
  | { valid: false; status: "invalid" | "expired" | "revoked" | "device_locked"; code: string; message: string; key?: string; expiresAt?: string | null; deviceId?: string | null };

export async function validateKey(rawKey: string, rawDeviceId?: string): Promise<ValidationResult> {
  await ensureKeySchema();
  const key = rawKey.trim().toUpperCase();
  if (!/^[A-F0-9]{5}(?:-[A-F0-9]{5}){3}$/.test(key)) {
    return { valid: false, status: "invalid", code: "invalid_format", message: "Key format must be XXXXX-XXXXX-XXXXX-XXXXX." };
  }
  const deviceId = rawDeviceId?.trim().slice(0, 128).toUpperCase() || null;
  const connection = await db().getConnection();
  try {
    await connection.beginTransaction();
    const [rows] = await connection.query<DbKey[]>(`SELECT ${selectColumns} FROM ghost_license_keys WHERE license_key = ? FOR UPDATE`, [key]);
    const row = rows[0];
    if (!row) {
      await connection.commit();
      return { valid: false, status: "invalid", code: "key_not_found", message: "License key was not found." };
    }
    const record = toLicenseKey(row);
    if (row.status === "revoked") {
      await connection.commit();
      return { valid: false, status: "revoked", code: "key_revoked", message: "License key has been revoked.", key, expiresAt: row.expiresAt, deviceId: row.deviceId };
    }
    if (record.status === "expired") {
      await connection.commit();
      return { valid: false, status: "expired", code: "key_expired", message: "License key has expired.", key, expiresAt: row.expiresAt, deviceId: row.deviceId };
    }
    if (row.deviceLocked) {
      await connection.commit();
      return { valid: false, status: "device_locked", code: "device_locked", message: "Key is locked after a device mismatch. Contact an administrator.", key, expiresAt: row.expiresAt, deviceId: row.deviceId };
    }
    if (deviceId && row.deviceId && row.deviceId !== deviceId) {
      await connection.execute(`UPDATE ghost_license_keys SET device_locked = 1 WHERE license_key = ?`, [key]);
      await connection.commit();
      return { valid: false, status: "device_locked", code: "device_mismatch", message: "License key is already bound to another device.", key, expiresAt: row.expiresAt, deviceId: row.deviceId };
    }
    if (deviceId && !row.deviceId) {
      await connection.execute(`UPDATE ghost_license_keys SET device_id = ? WHERE license_key = ?`, [deviceId, key]);
    }
    await connection.execute(`UPDATE ghost_license_keys SET uses = uses + 1, last_used_at = ? WHERE license_key = ?`, [mysqlUtc(new Date()), key]);
    await connection.commit();
    return { valid: true, status: "active", message: "License key is valid.", key, expiresAt: row.expiresAt, uses: Number(row.uses) + 1, deviceId: row.deviceId || deviceId };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}
