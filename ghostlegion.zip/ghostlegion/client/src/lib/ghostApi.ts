export async function ghostApi<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(path, {
    ...init,
    credentials: "include",
    headers: {
      ...(init.body ? { "Content-Type": "application/json" } : {}),
      ...init.headers,
    },
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = typeof payload?.message === "string" ? payload.message : `Request failed (${response.status})`;
    throw new Error(message);
  }
  return payload as T;
}

export function formatKeyInput(value: string): string {
  const raw = value.toUpperCase().replace(/[^A-F0-9]/g, "").slice(0, 20);
  return raw.match(/.{1,5}/g)?.join("-") ?? "";
}
