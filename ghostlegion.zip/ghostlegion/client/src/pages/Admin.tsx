import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import {
  ArrowUpRight, Ban, Check, CheckCircle2, CircleSlash, Clock3, Code2, Copy,
  Fingerprint, KeyRound, LogOut, RotateCcw, RotateCw, Search, ShieldCheck,
  Sparkles, Trash2, X, Loader2,
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { startLogin } from "../const";
import { GhostBrand } from "../components/GhostBrand";
import { formatKeyInput, ghostApi } from "../lib/ghostApi";

type KeyStatus = "active" | "expired" | "revoked";
type LicenseKey = {
  key: string;
  duration: string;
  note: string | null;
  createdAt: string;
  expiresAt: string | null;
  deviceId: string | null;
  deviceLocked: boolean;
  status: KeyStatus;
  uses: number;
};
type SessionInfo = { authenticated: boolean; isAdmin: boolean; user?: { name: string | null; email: string | null } };
type Filter = "all" | KeyStatus;

const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "ALL" },
  { id: "active", label: "ACTIVE" },
  { id: "expired", label: "EXPIRED" },
  { id: "revoked", label: "REVOKED" },
];

const BASE_URL = typeof window === "undefined" ? "" : `${window.location.origin}/api`;

function dateLabel(value: string | null) {
  if (!value) return "LIFETIME";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")} ${String(date.getUTCHours()).padStart(2, "0")}:${String(date.getUTCMinutes()).padStart(2, "0")}`;
}

function StatusBadge({ status }: { status: KeyStatus }) {
  const Icon = status === "active" ? CheckCircle2 : status === "expired" ? Clock3 : CircleSlash;
  return <span className={`status-badge status-${status}`}><Icon size={12} />{status.toUpperCase()}</span>;
}

function Metric({ label, value, accent, icon }: { label: string; value: number; accent: string; icon: React.ReactNode }) {
  return (
    <div className={`metric-card ${accent}`}>
      <span className="metric-icon">{icon}</span>
      <div className="metric-label">{label}</div>
      <div className="metric-value">{value}</div>
    </div>
  );
}

function AuthGate({ state }: { state: "checking" | "signed-out" | "forbidden" }) {
  return (
    <main className="auth-page">
      <header className="auth-topbar"><GhostBrand subtitle="SECURE ACCESS" /></header>
      <section className="auth-card">
        <div className="auth-emblem"><span className="gate-lock"><KeyRound size={25} /></span></div>
        <div className="eyebrow"><span className="live-dot" /> ADMIN AUTHENTICATION</div>
        {state === "checking" ? <><h1>Checking <span>credentials.</span></h1><p className="auth-lede">Verifying access to the license control console.</p><div className="auth-status"><Loader2 size={16} className="spin" /> Checking secure session</div></> : state === "forbidden" ? <><h1>Access <span>restricted.</span></h1><p className="auth-lede">This signed-in account does not have administrator access.</p><Link href="/" className="button-secondary">Return to validator <ArrowUpRight size={14} /></Link></> : <><h1>Access the <span>legion.</span></h1><p className="auth-lede">Sign in with the administrator account to manage license keys, devices and validation activity.</p><button className="button-primary auth-button" onClick={() => startLogin()}><KeyRound size={16} /> Continue with Manus <ArrowUpRight size={15} /></button><div className="auth-foot"><span className="auth-foot-lock" /> Protected administrator access</div></>}
      </section>
      <footer className="auth-footer"><span>GHOST LEGION · KEY CONTROL</span><Link href="/">RETURN TO VALIDATOR</Link></footer>
    </main>
  );
}

export default function AdminPage() {
  const [, navigate] = useLocation();
  const [gate, setGate] = useState<"checking" | "signed-out" | "forbidden" | "ready">("checking");
  const [adminName, setAdminName] = useState("ADMINISTRATOR");
  const [keys, setKeys] = useState<LicenseKey[]>([]);
  const [loadingKeys, setLoadingKeys] = useState(false);
  const [filter, setFilter] = useState<Filter>("all");
  const [search, setSearch] = useState("");
  const [duration, setDuration] = useState("custom");
  const [customDays, setCustomDays] = useState(10);
  const [quantity, setQuantity] = useState(1);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [generated, setGenerated] = useState<LicenseKey[]>([]);
  const [copied, setCopied] = useState<string | null>(null);

  const refreshKeys = useCallback(async () => {
    setLoadingKeys(true);
    try {
      const result = await ghostApi<{ keys: LicenseKey[] }>("/api/admin/keys");
      setKeys(result.keys);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not load the key registry.");
    } finally {
      setLoadingKeys(false);
    }
  }, []);

  useEffect(() => {
    let active = true;
    ghostApi<SessionInfo>("/api/admin/session")
      .then(session => {
        if (!active) return;
        if (!session.authenticated) setGate("signed-out");
        else if (!session.isAdmin) setGate("forbidden");
        else {
          setAdminName(session.user?.name || session.user?.email || "ADMINISTRATOR");
          setGate("ready");
          void refreshKeys();
        }
      })
      .catch(() => active && setGate("signed-out"));
    return () => { active = false; };
  }, [refreshKeys]);

  const metrics = useMemo(() => ({
    total: keys.length,
    active: keys.filter(key => key.status === "active").length,
    expired: keys.filter(key => key.status === "expired").length,
    revoked: keys.filter(key => key.status === "revoked").length,
    locked: keys.filter(key => key.deviceLocked).length,
  }), [keys]);

  const visibleKeys = useMemo(() => {
    const term = search.trim().toUpperCase();
    return keys.filter(key => {
      const matchesFilter = filter === "all" || key.status === filter;
      const matchesSearch = !term || [key.key, key.deviceId ?? "", key.note ?? ""].some(value => value.toUpperCase().includes(term));
      return matchesFilter && matchesSearch;
    });
  }, [keys, filter, search]);

  async function copyText(value: string, key = value) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(key);
      window.setTimeout(() => setCopied(current => current === key ? null : current), 1300);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Clipboard access is unavailable in this browser.");
    }
  }

  async function generateKeys(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    try {
      const result = await ghostApi<{ keys: LicenseKey[] }>("/api/admin/keys", {
        method: "POST",
        body: JSON.stringify({ quantity, duration, customDays: duration === "custom" ? customDays : undefined, note }),
      });
      setGenerated(result.keys);
      await refreshKeys();
      toast.success(`${result.keys.length} ${result.keys.length === 1 ? "key" : "keys"} generated`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Key generation failed.");
    } finally {
      setBusy(false);
    }
  }

  async function keyAction(key: LicenseKey, action: "revoke" | "restore" | "unlock") {
    const prompt = action === "revoke" ? "Revoke this license key?" : action === "unlock" ? "Clear the bound device and unlock this key?" : "Restore this license key?";
    if (!window.confirm(prompt)) return;
    try {
      await ghostApi(`/api/admin/keys/${encodeURIComponent(key.key)}/action`, { method: "POST", body: JSON.stringify({ action }) });
      await refreshKeys();
      toast.success(action === "unlock" ? "Device binding cleared" : `Key ${action}d`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not update this key.");
    }
  }

  async function deleteKey(key: LicenseKey) {
    if (!window.confirm(`Permanently delete ${key.key}? This cannot be undone.`)) return;
    try {
      await ghostApi(`/api/admin/keys/${encodeURIComponent(key.key)}`, { method: "DELETE" });
      await refreshKeys();
      toast.success("Key deleted");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not delete this key.");
    }
  }

  async function logout() {
    try { await ghostApi("/api/admin/logout", { method: "POST" }); } catch { /* continue to login */ }
    navigate("/login");
  }

  if (gate !== "ready") return <AuthGate state={gate} />;

  return (
    <main className="console-page">
      <header className="console-topbar">
        <div className="console-topbar-inner">
          <GhostBrand />
          <div className="console-account"><span className="admin-identity"><span className="online-indicator" />{adminName}</span><button className="logout-button" onClick={logout}><LogOut size={14} /> LOGOUT</button></div>
        </div>
      </header>

      <div className="console-main">
        <section className="metrics-grid" aria-label="License key statistics">
          <Metric label="TOTAL KEYS" value={metrics.total} accent="metric-total" icon={<KeyRound size={15} />} />
          <Metric label="ACTIVE" value={metrics.active} accent="metric-active" icon={<ShieldCheck size={15} />} />
          <Metric label="EXPIRED" value={metrics.expired} accent="metric-expired" icon={<Clock3 size={15} />} />
          <Metric label="REVOKED" value={metrics.revoked} accent="metric-revoked" icon={<CircleSlash size={15} />} />
          <Metric label="DEVICE-LOCKED" value={metrics.locked} accent="metric-locked" icon={<Fingerprint size={15} />} />
        </section>

        <div className="console-columns">
          <aside className="console-side">
            <section className="panel generate-panel">
              <div className="panel-heading"><Sparkles size={17} /><h2>Generate keys</h2></div>
              <div className="key-format"><span>FORMAT</span> XXXXX-XXXXX-XXXXX-XXXXX <i>· uppercase hex</i></div>
              <form onSubmit={generateKeys}>
                <label className="field-label" htmlFor="duration">EXPIRATION</label>
                <select id="duration" className="field-control duration-select" value={duration} onChange={event => setDuration(event.target.value)}>
                  <option value="1d">1 day</option><option value="7d">7 days</option><option value="30d">30 days</option><option value="90d">90 days</option><option value="365d">365 days</option><option value="lifetime">Lifetime</option><option value="custom">Custom duration</option>
                </select>
                {duration === "custom" ? <div className="field-hint custom-duration"><input aria-label="Custom duration in days" className="custom-days" type="number" min={1} max={365} value={customDays} onChange={event => setCustomDays(Number(event.target.value))} /><span>between 1 and 365 days</span></div> : <div className="field-hint">{duration === "lifetime" ? "No expiration" : "Duration from creation date"}</div>}

                <div className="field-row">
                  <div className="quantity-field"><label className="field-label" htmlFor="quantity">QTY</label><input id="quantity" className="field-control" type="number" min={1} max={100} value={quantity} onChange={event => setQuantity(Math.max(1, Math.min(100, Number(event.target.value))))} /></div>
                  <div className="note-field"><label className="field-label" htmlFor="note">NOTE (OPTIONAL)</label><input id="note" className="field-control" maxLength={255} placeholder="buyer / order #" value={note} onChange={event => setNote(event.target.value)} /></div>
                </div>
                <button type="submit" className="button-primary generate-button" disabled={busy || (duration === "custom" && (customDays < 1 || customDays > 365))}>
                  {busy ? <Loader2 size={16} className="spin" /> : <Sparkles size={15} />} GENERATE KEY
                </button>
              </form>
              {generated.length > 0 && (
                <div className="generated-box">
                  <div className="generated-meta"><span>NEW · {generated[0].duration.toUpperCase()}</span><button onClick={() => void copyText(generated.map(item => item.key).join("\n"), "all-generated")}><Copy size={12} /> {copied === "all-generated" ? "COPIED" : "COPY ALL"}</button></div>
                  {generated.map(item => <div className="generated-key" key={item.key}><code>{item.key}</code><button className="icon-button small-icon" aria-label={`Copy ${item.key}`} onClick={() => void copyText(item.key)}>{copied === item.key ? <Check size={14} /> : <Copy size={13} />}</button></div>)}
                </div>
              )}
            </section>

            <section className="panel integration-panel">
              <div className="panel-heading integration-heading"><Code2 size={16} /><h2>APK integration</h2></div>
              <p className="integration-copy">POST either endpoint with a key and optional device fingerprint.</p>
              <div className="endpoint-list">
                {[`${BASE_URL}`, `${BASE_URL}/validate`].map(endpoint => (
                  <div className="endpoint-row" key={endpoint}>
                    <span className="method-pill">POST</span>
                    <code title={endpoint}>{endpoint}</code>
                    <button className="icon-button copy-endpoint" aria-label={`Copy ${endpoint}`} onClick={() => void copyText(endpoint, endpoint)}>{copied === endpoint ? <Check size={13} /> : <Copy size={13} />}</button>
                  </div>
                ))}
              </div>
              <pre className="api-example"><span>REQUEST BODY</span><code>{`{
  "key": "XXXXX-XXXXX-XXXXX-XXXXX",
  "device_id": "YOUR_DEVICE_ID"
}`}</code></pre>
              <Link href="/api" className="api-doc-link" target="_blank">API STATUS &amp; FORMAT <ArrowUpRight size={13} /></Link>
            </section>
          </aside>

          <section className="panel keys-panel">
            <div className="keys-toolbar">
              <div className="keys-title"><h2>License keys</h2><span>{visibleKeys.length} of {keys.length} shown</span></div>
              <div className="keys-tools">
                <div className="filter-tabs" role="tablist" aria-label="Filter keys">
                  {FILTERS.map(item => <button key={item.id} role="tab" aria-selected={filter === item.id} className={filter === item.id ? "filter-tab selected" : "filter-tab"} onClick={() => setFilter(item.id)}>{item.label}</button>)}
                </div>
                <label className="search-box"><Search size={15} /><input aria-label="Search license keys" placeholder="search key / hwid / note" value={search} onChange={event => setSearch(event.target.value)} />{search && <button onClick={() => setSearch("")} aria-label="Clear search"><X size={13} /></button>}</label>
              </div>
            </div>

            <div className="table-wrap">
              <table className="key-table">
                <thead><tr><th>KEY</th><th>DURATION</th><th>CREATED</th><th>EXPIRES</th><th>DEVICE (HWID)</th><th>STATUS</th><th>USES</th><th aria-label="Actions" /></tr></thead>
                <tbody>
                  {loadingKeys && keys.length === 0 ? <tr><td colSpan={8} className="empty-state"><Loader2 size={18} className="spin" /> Loading registry…</td></tr> : visibleKeys.length === 0 ? <tr><td colSpan={8} className="empty-state"><KeyRound size={19} /><strong>{keys.length === 0 ? "No keys generated yet" : "No matching keys"}</strong><span>{keys.length === 0 ? "Generate a key to populate the license registry." : "Change the filter or search query."}</span></td></tr> : visibleKeys.map(key => (
                    <tr key={key.key}>
                      <td className="key-cell"><code>{key.key}</code>{key.note && <small>{key.note}</small>}</td>
                      <td className="duration-cell">{key.duration}</td>
                      <td className="date-cell">{dateLabel(key.createdAt)}</td>
                      <td className="date-cell">{dateLabel(key.expiresAt)}</td>
                      <td className={`device-cell${key.deviceLocked ? " device-locked" : ""}`}>{key.deviceId ? <span title={key.deviceId}>{key.deviceId.length > 16 ? `${key.deviceId.slice(0, 13)}…` : key.deviceId}</span> : <i>unbound</i>}</td>
                      <td><StatusBadge status={key.status} />{key.deviceLocked && <span className="mini-lock">LOCKED</span>}</td>
                      <td className="uses-cell">{key.uses}</td>
                      <td className="row-actions">
                        {key.status === "revoked" ? <button className="icon-button action-restore" title="Restore key" aria-label="Restore key" onClick={() => void keyAction(key, "restore")}><RotateCw size={15} /></button> : <button className="icon-button action-revoke" title="Revoke key" aria-label="Revoke key" onClick={() => void keyAction(key, "revoke")}><Ban size={15} /></button>}
                        <button className={`icon-button${key.deviceLocked ? " action-unlock" : ""}`} title={key.deviceLocked ? "Unlock device" : "Reset device binding"} aria-label={key.deviceLocked ? "Unlock device" : "Reset device binding"} onClick={() => void keyAction(key, "unlock")}><RotateCcw size={15} /></button>
                        <button className="icon-button action-delete" title="Delete key" aria-label="Delete key" onClick={() => void deleteKey(key)}><Trash2 size={15} /></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="table-footer"><span><span className="status-dot" /> REGISTRY SYNCHRONIZED</span><button onClick={() => void refreshKeys()} disabled={loadingKeys}><RotateCcw size={12} className={loadingKeys ? "spin" : ""} /> REFRESH</button></div>
          </section>
        </div>
        <div className="console-footer"><span>GHOST LEGION KEY MANAGEMENT</span><span>ADMIN CONSOLE <b>·</b> {adminName.toUpperCase()}</span></div>
      </div>
    </main>
  );
}
