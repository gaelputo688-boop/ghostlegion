import { useEffect, useState } from "react";
import { ArrowRight, LockKeyhole, ShieldCheck } from "lucide-react";
import { Link, useLocation } from "wouter";
import { startLogin } from "../const";
import { GhostBrand, GhostMark } from "../components/GhostBrand";
import { ghostApi } from "../lib/ghostApi";

type SessionInfo = { authenticated: boolean; isAdmin: boolean; user?: { name: string | null; email: string | null } };

export default function LoginPage() {
  const [, navigate] = useLocation();
  const [state, setState] = useState<"checking" | "signed-out" | "not-admin" | "ready">("checking");

  useEffect(() => {
    let active = true;
    ghostApi<SessionInfo>("/api/admin/session")
      .then(session => {
        if (!active) return;
        if (session.authenticated && session.isAdmin) {
          setState("ready");
          navigate("/admin");
        } else if (session.authenticated) {
          setState("not-admin");
        } else {
          setState("signed-out");
        }
      })
      .catch(() => active && setState("signed-out"));
    return () => { active = false; };
  }, [navigate]);

  return (
    <main className="auth-page">
      <header className="auth-topbar"><GhostBrand subtitle="SECURE ACCESS" /></header>
      <section className="auth-card">
        <div className="auth-emblem"><GhostMark /></div>
        <div className="eyebrow"><span className="live-dot" /> ADMIN AUTHENTICATION</div>
        <h1>Access the <span>legion.</span></h1>
        <p className="auth-lede">Sign in with the administrator account to manage license keys, devices and validation activity.</p>
        {state === "checking" || state === "ready" ? (
          <div className="auth-status"><span className="spinner" /> Checking secure session</div>
        ) : state === "not-admin" ? (
          <div className="auth-warning"><ShieldCheck size={17} /> This account is signed in but does not have administrator access.</div>
        ) : (
          <button className="button-primary auth-button" onClick={() => startLogin()}>
            <LockKeyhole size={16} /> Continue with Manus <ArrowRight size={16} />
          </button>
        )}
        <div className="auth-foot"><LockKeyhole size={13} /> Protected by administrator authentication</div>
      </section>
      <footer className="auth-footer"><span>GHOST LEGION · KEY CONTROL</span><Link href="/">RETURN TO VALIDATOR</Link></footer>
    </main>
  );
}
