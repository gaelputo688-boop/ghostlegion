import { useState } from "react";
import { ArrowUpRight, CheckCircle2, KeyRound, LockKeyhole, ShieldCheck, ShieldX } from "lucide-react";
import { Link } from "wouter";
import { GhostBrand } from "../components/GhostBrand";
import { ghostApi, formatKeyInput } from "../lib/ghostApi";

type ValidationResponse = {
  valid: boolean;
  status: string;
  message: string;
  code?: string;
  expiresAt?: string | null;
  uses?: number;
  deviceId?: string | null;
};

export default function Home() {
  const [key, setKey] = useState("");
  const [deviceId, setDeviceId] = useState("");
  const [result, setResult] = useState<ValidationResponse | null>(null);
  const [busy, setBusy] = useState(false);

  async function validate(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setResult(null);
    try {
      setResult(await ghostApi<ValidationResponse>("/api/validate", {
        method: "POST",
        body: JSON.stringify({ key, device_id: deviceId || undefined }),
      }));
    } catch (error) {
      setResult({ valid: false, status: "error", message: error instanceof Error ? error.message : "Validation service is unavailable." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="public-page">
      <header className="public-topbar">
        <GhostBrand subtitle="LICENSE AUTHENTICATION" compact />
        <Link className="admin-link" href="/login">ADMIN LOGIN <ArrowUpRight size={14} /></Link>
      </header>
      <section className="validator-wrap">
        <div className="validator-orbit" aria-hidden="true"><span /><span /><span /></div>
        <div className="eyebrow"><span className="live-dot" /> LICENSE GATEWAY <span className="eyebrow-divider">/</span> SYSTEM ONLINE</div>
        <h1>Ghost Legion<br /><span>Key Validator</span></h1>
        <p className="validator-lede">Verify a license key against the Ghost Legion registry.</p>
        <form className="validator-card" onSubmit={validate}>
          <label htmlFor="license-key">LICENSE KEY</label>
          <div className="input-with-icon"><KeyRound size={17} /><input id="license-key" autoComplete="off" spellCheck={false} placeholder="XXXXX-XXXXX-XXXXX-XXXXX" value={key} onChange={event => setKey(formatKeyInput(event.target.value))} required /></div>
          <div className="form-hint">20-character hexadecimal key · 4 groups</div>
          <label htmlFor="device-id" className="device-label">DEVICE ID <span>OPTIONAL</span></label>
          <div className="input-with-icon"><LockKeyhole size={16} /><input id="device-id" autoComplete="off" spellCheck={false} placeholder="Enter device fingerprint" value={deviceId} onChange={event => setDeviceId(event.target.value)} /></div>
          <button className="button-primary validate-button" type="submit" disabled={busy || key.length < 23}>
            {busy ? <span className="spinner spinner-dark" /> : <ShieldCheck size={17} />}
            {busy ? "CHECKING REGISTRY" : "VALIDATE LICENSE"}
          </button>
          {result && (
            <div className={`validation-result ${result.valid ? "result-good" : "result-bad"}`} role="status">
              {result.valid ? <CheckCircle2 size={20} /> : <ShieldX size={20} />}
              <div><strong>{result.valid ? "KEY VERIFIED" : result.status.toUpperCase().replaceAll("_", " ")}</strong><span>{result.message}</span></div>
              {result.valid && <i>AUTHORIZED</i>}
            </div>
          )}
        </form>
        <div className="validator-meta"><span><span className="status-dot" /> SECURE VALIDATION</span><span>END-TO-END KEY CHECK</span></div>
      </section>
      <footer className="public-footer"><span>© GHOST LEGION · KEY CONTROL</span><a href="/api" target="_blank" rel="noreferrer">API STATUS <ArrowUpRight size={12} /></a></footer>
    </main>
  );
}
