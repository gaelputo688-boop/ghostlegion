import { Link } from "wouter";

export function GhostMark({ small = false }: { small?: boolean }) {
  return (
    <svg className={small ? "ghost-mark ghost-mark-small" : "ghost-mark"} viewBox="0 0 40 44" aria-hidden="true">
      <path d="M20 2.5C10.3 2.5 4 10 4 19.6v19.8l5.3-4.1 5.1 4.1 5.6-4.2 5.4 4.2 5.2-4.1 5.4 4.1V19.6C36 10 29.7 2.5 20 2.5Z" fill="currentColor" />
      <ellipse cx="14.1" cy="19" rx="2.1" ry="3.1" fill="#080a0c" />
      <ellipse cx="25.9" cy="19" rx="2.1" ry="3.1" fill="#080a0c" />
      <path d="M15.2 27.5h2.1v2.7h-2.1zm7.5 0h2.1v2.7h-2.1z" fill="#080a0c" opacity=".75" />
    </svg>
  );
}

export function GhostBrand({ subtitle = "KEY MANAGEMENT CONSOLE", compact = false }: { subtitle?: string; compact?: boolean }) {
  return (
    <Link href="/" className={`brand-lockup${compact ? " brand-lockup-compact" : ""}`} aria-label="Ghost Legion home">
      <GhostMark />
      <span className="brand-copy">
        <span className="brand-title">Ghost Legion <b>Admin</b></span>
        {!compact && <span className="brand-subtitle">{subtitle}</span>}
      </span>
    </Link>
  );
}
