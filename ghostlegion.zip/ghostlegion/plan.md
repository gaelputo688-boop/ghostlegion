# Ghost Legion Key Validator — Plan

## Alcance
Construir desde cero un validador de licencias con interfaz fiel a la captura entregada por el usuario: panel de administración oscuro, cabecera Ghost Legion Admin, cinco tarjetas de métricas, formulario de generación, tabla de claves con filtros/búsqueda/acciones y tarjeta APK Integration. Añadir acceso administrativo, validador público y API REST en `/api` y `/api/validate`. La clave generada debe seguir `XXXXX-XXXXX-XXXXX-XXXXX` en hexadecimal mayúsculo.

## Diseño
- **Estética:** consola táctica oscura con acentos de neón, guiada directamente por la captura del usuario.
- **Principios:** alta legibilidad en una tabla densa; jerarquía basada en contornos y color de estado; controles de administración directos; diseño adaptable a móvil.
- **Paleta:** negro carbón y violeta azulado muy oscuro, verde neón para acciones/estado activo, rojo para expiradas, cian para bloqueo de dispositivo y gris para revocadas.
- **Composición:** barra de marca superior; banda horizontal de cinco métricas; contenido en dos columnas con generación/API a la izquierda y gestión de claves a la derecha.
- **Motivos:** sello fantasma, trazos finos luminosos y etiquetas monoespaciadas con tracking amplio.
- **Interacción:** generación con duración, cantidad y nota opcional; copiar claves y endpoints; filtro/búsqueda; revocar, restaurar, liberar dispositivo y borrar.
- **Tipografía:** sans legible para contenido y monoespaciada para identificadores, metadatos y etiquetas.
- **Marca:** Ghost Legion como consola de gestión de licencias; técnica, sobria y precisa. Voz breve, estilo sistema operativo, por ejemplo “LICENSE CONTROL / READY” y “Key generated”.

## Implementación y estructura
- `client/src/pages`: validador público, login y consola `/admin`.
- `client/src/index.css`: sistema visual de la consola, responsive.
- `server/keyStore.ts`: persistencia MySQL y operaciones de claves; creación aditiva de tablas idempotentes.
- `server/_core/index.ts`: REST `/api`, `/api/validate` y endpoints de administración, manteniendo el login Manus OAuth y tRPC existentes.
- `client/public/manus-routes.json`: rutas web declaradas.
- MySQL administrado para conservar claves, expiración, huella de dispositivo, estado y usos.
- El panel requiere el usuario con rol de administrador; el acceso usa el OAuth existente, no credenciales predeterminadas embebidas.

## Comportamiento API
`GET /api` describe servicio, formato y endpoints. `POST /api` y `POST /api/validate` aceptan `{ "key": "XXXXX-XXXXX-XXXXX-XXXXX", "device_id": "..." }`. La primera huella opcional se vincula a la clave; una huella distinta bloquea la clave hasta liberarla desde `/admin`. La respuesta es JSON con resultado, estado, expiración y usos.

## Publicación
Prioridad a una URL de producción corta, menor de 37 caracteres. Se usará la publicación administrada disponible en el entorno si no hay sesión/credenciales de Vercel, Render o Netlify; no se pedirá al usuario crear cuenta.
