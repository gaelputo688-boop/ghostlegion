# TODO

- [x] **Consola visual y navegación** — Mantener la identidad Ghost Legion; mostrar pantalla de login y panel de administración en `/admin`; reproducir el diseño de la captura: cinco contadores (Total Keys, Active, Expired, Revoked, Device-Locked), panel Generate keys, tabla License keys, filtros, búsqueda y bloque APK integration; adaptar a pantallas pequeñas.
- [x] **Generación y gestión de claves** — Generar claves con el mismo formato `XXXXX-XXXXX-XXXXX-XXXXX` y mayúsculas; ofrecer duraciones, cantidad y nota opcional; mostrar expiración, dispositivo/HWID, estado y usos; permitir copiar, revocar/restaurar, liberar dispositivo y borrar; persistir claves.
- [x] **API de validación** — Hacer que `/api` responda con documentación de endpoints y que `/api/validate` responda a solicitudes de validación JSON; aceptar claves en el formato solicitado y devolver resultado claro para claves inexistentes, activas, expiradas, revocadas o bloqueadas por dispositivo.
- [x] **Acceso administrativo** — Proteger la consola para administradores usando el inicio de sesión existente; no incluir contraseñas predeterminadas inseguras.
- [ ] **Producción** — Publicar en hosting gratuito accesible desde el entorno y entregar una URL de producción de menos de 37 caracteres; probar la página y las rutas API publicadas.
